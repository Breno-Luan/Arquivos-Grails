//= require ${request.contextPath}/js/easygrid.jqgrid
//= require ${request.contextPath}/js/selection/selectionWidget.js